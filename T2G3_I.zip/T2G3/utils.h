#include <time.h>
#include <stdio.h>
#include <stdlib.h>

void startTime();

double elapsedTime();